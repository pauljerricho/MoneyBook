using Dapper;
using Microsoft.Data.Sqlite;
using MoneyBook.Core;

namespace MoneyBook.Data;

public sealed class TransactionRepository
{
    public async Task<long> AddAsync(Transaction tx)
    {
        using var con = new SqliteConnection(Db.ConnectionString);
        const string sql = @"INSERT INTO Transactions(Date,Amount,Category,Memo,Type) 
                             VALUES(@Date,@Amount,@Category,@Memo,@Type);
                             SELECT last_insert_rowid();";
        var id = await con.ExecuteScalarAsync<long>(sql, new {
            Date = tx.Date.ToString("yyyy-MM-dd"),
            tx.Amount, tx.Category, tx.Memo, Type = (int)tx.Type
        });
        tx.Id = id;
        return id;
    }

    public async Task<int> UpdateAsync(Transaction tx)
    {
        using var con = new SqliteConnection(Db.ConnectionString);
        const string sql = @"UPDATE Transactions
                             SET Date=@Date, Amount=@Amount, Category=@Category, Memo=@Memo, Type=@Type
                             WHERE Id=@Id";
        return await con.ExecuteAsync(sql, new {
            Date = tx.Date.ToString("yyyy-MM-dd"),
            tx.Amount, tx.Category, tx.Memo, Type = (int)tx.Type, tx.Id
        });
    }

    public async Task<int> DeleteAsync(long id)
    {
        using var con = new SqliteConnection(Db.ConnectionString);
        return await con.ExecuteAsync("DELETE FROM Transactions WHERE Id=@id", new { id });
    }

    public async Task<IEnumerable<Transaction>> QueryAsync()
    {
        using var con = new SqliteConnection(Db.ConnectionString);
        const string sql = "SELECT Id, Date, Amount, Category, Memo, Type FROM Transactions ORDER BY Date DESC, Id DESC";
        return await con.QueryAsync<Transaction>(sql);
    }
}