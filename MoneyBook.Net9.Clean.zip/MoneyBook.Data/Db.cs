using Microsoft.Data.Sqlite;

namespace MoneyBook.Data;

public static class Db
{
    public static string DbPath { get; set; } = Path.GetFullPath("moneybook.db");
    public static string ConnectionString => $"Data Source={DbPath}";

    public static void EnsureCreated()
    {
        if (!File.Exists(DbPath))
        {
            using var con = new SqliteConnection(ConnectionString);
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Transactions(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Date TEXT NOT NULL,
    Amount REAL NOT NULL,
    Category TEXT NOT NULL,
    Memo TEXT,
    Type INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_Transactions_Date ON Transactions(Date);";
            cmd.ExecuteNonQuery();
        }
    }
}