namespace MoneyBook.Core;

public enum TransactionType { Income = 1, Expense = 2, Transfer = 3 }

public sealed class Transaction
{
    public long Id { get; set; }
    public DateTime Date { get; set; }
    public decimal Amount { get; set; }
    public string Category { get; set; } = string.Empty;
    public string Memo { get; set; } = string.Empty;
    public TransactionType Type { get; set; }
}

public sealed class Summary
{
    public decimal Income { get; set; }
    public decimal Expense { get; set; }
    public decimal Net => Income - Expense;
}