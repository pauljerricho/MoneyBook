using MoneyBook.Core;
using MoneyBook.Data;

namespace MoneyBook.Services;

public sealed class MoneyService
{
    private readonly TransactionRepository _repo = new();

    public async Task<Summary> GetMonthlySummaryAsync(DateTime month)
    {
        var from = new DateTime(month.Year, month.Month, 1);
        var to = from.AddMonths(1).AddDays(-1);
        var list = await _repo.QueryAsync();
        var filtered = list.Where(x => x.Date >= from && x.Date <= to);
        return new Summary
        {
            Income = filtered.Where(x => x.Type == TransactionType.Income).Sum(x => x.Amount),
            Expense = filtered.Where(x => x.Type == TransactionType.Expense).Sum(x => x.Amount)
        };
    }
}