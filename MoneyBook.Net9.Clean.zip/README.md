# MoneyBook – Clean WinForms (.NET 9)

최소 구성(차트/외부 UI 라이브러리 제거):
- WinForms + DataGridView 기반 가계부 CRUD
- SQLite (Microsoft.Data.Sqlite 9.0.0) + Dapper 2.1.35
- 첫 실행 시 `moneybook.db` 자동 생성

## Build
1) `MoneyBook.Net9.sln` 열기 (VS 2022)
2) NuGet 복원
3) 시작 프로젝트 `MoneyBook.UI`로 실행 ▶