using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MoneyBook.Core;
using MoneyBook.Data;
using MoneyBook.Services;

namespace MoneyBook.UI;

public sealed class MainForm : Form
{
    private readonly DataGridView _grid = new() { Dock = DockStyle.Fill, AutoGenerateColumns = false, AllowUserToAddRows = false };
    private readonly StatusStrip _status = new();
    private readonly ToolStripStatusLabel _lblSummary = new();
    private readonly TransactionRepository _repo = new();
    private readonly MoneyService _svc = new();

    public MainForm()
    {
        Text = "MoneyBook – 가계부 (클린)";
        Width = 1000;
        Height = 640;

        // Toolbar
        var tool = new ToolStrip();
        var btnAdd = new ToolStripButton("추가");
        var btnSave = new ToolStripButton("저장");
        var btnDelete = new ToolStripButton("삭제");
        tool.Items.AddRange(new[] { btnAdd, btnSave, btnDelete });

        btnAdd.Click += (s, e) =>
        {
            if (_grid.DataSource is BindingSource bs)
                bs.Add(new Transaction { Date = DateTime.Today, Type = TransactionType.Expense });
        };

        btnSave.Click += async (s, e) => await SaveAllAsync();

        btnDelete.Click += async (s, e) =>
        {
            if (_grid.CurrentRow?.DataBoundItem is Transaction tx && tx.Id > 0)
            {
                await _repo.DeleteAsync(tx.Id);
                await LoadDataAsync();
            }
        };

        // Grid
        SetupGrid();

        // Status
        _status.Items.Add(_lblSummary);

        Controls.Add(_grid);
        Controls.Add(tool);
        Controls.Add(_status);

        tool.Dock = DockStyle.Top;
        _status.Dock = DockStyle.Bottom;

        Load += async (s, e) => await LoadDataAsync();
        _grid.CellEndEdit += async (s, e) => await SaveRowAsync(e.RowIndex);
    }

    private void SetupGrid()
    {
        _grid.Columns.Clear();
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Id", HeaderText = "Id", Width = 60, ReadOnly = true });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Date", HeaderText = "Date", Width = 110, DefaultCellStyle = new DataGridViewCellStyle { Format = "yyyy-MM-dd" } });
        _grid.Columns.Add(new DataGridViewComboBoxColumn { DataPropertyName = "Type", HeaderText = "Type", Width = 100, DataSource = Enum.GetValues(typeof(TransactionType)) });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Category", HeaderText = "Category", Width = 180 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Amount", HeaderText = "Amount", Width = 120, DefaultCellStyle = new DataGridViewCellStyle { Format = "N0", Alignment = DataGridViewContentAlignment.MiddleRight } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Memo", HeaderText = "Memo", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
    }

    private async Task LoadDataAsync()
    {
        var list = (await _repo.QueryAsync()).ToList();
        _grid.DataSource = new BindingSource { DataSource = list };

        var summary = await _svc.GetMonthlySummaryAsync(DateTime.Today);
        _lblSummary.Text = $"수입: {summary.Income:N0} | 지출: {summary.Expense:N0} | 순이익: {summary.Net:N0}";
    }

    private async Task SaveRowAsync(int rowIndex)
    {
        if (rowIndex < 0 || rowIndex >= _grid.Rows.Count) return;
        if (_grid.Rows[rowIndex].DataBoundItem is Transaction tx)
        {
            if (tx.Id == 0) await _repo.AddAsync(tx);
            else await _repo.UpdateAsync(tx);
            await LoadDataAsync();
        }
    }

    private async Task SaveAllAsync()
    {
        if (_grid.DataSource is BindingSource bs)
        {
            foreach (var item in bs.List.OfType<Transaction>())
            {
                if (item.Id == 0) await _repo.AddAsync(item);
                else await _repo.UpdateAsync(item);
            }
            await LoadDataAsync();
        }
    }
}